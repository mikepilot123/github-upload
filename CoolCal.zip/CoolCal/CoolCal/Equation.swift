//
//  Equation.swift
//  CoolCal
//
//  Created by Michael Nelson on 25/06/2021.
//

import Foundation


enum Operation: String{
    
    case add = "+"
        
    case subtract = "-"
        
    case multiply = "x"
        
    case divide = "/"
    
    
}

struct Equation {
    
    var firstNumber: Double
    var secondNumber: Double
    
    var operationValue: Operation
    

    
    
    
    func calculate() -> Double?{

        switch operationValue {
        case .add: return  firstNumber + secondNumber
            
        case .subtract: return firstNumber - secondNumber
            
        case .multiply: return firstNumber * secondNumber
            
        case .divide: return firstNumber / secondNumber
            

        }

        }



      
    
    
}
