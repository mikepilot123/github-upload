//
//  ViewController.swift
//  CoolCal
//
//  Created by Michael Nelson on 24/06/2021.
//

import UIKit

class ViewController: UIViewController {
    
//    Variables for equation
    
    @IBOutlet weak var firstNumberLbl: UILabel!
    @IBOutlet weak var operationSymbol: UILabel!
    @IBOutlet weak var secondNumberLbl: UILabel!
    
    
    
    
//    Variable for answer
    @IBOutlet weak var answerLabel: UILabel!
   
   
    var firstDigit: String = ""
    var secondDigit: String = ""
    var operationVal: String = ""
    var operationIsUpdated: Bool? = nil
    var decimalValue: Double = 0
    var auxiliaryOperatorIsPressed = false
    var auxiliaryButtonPressCount = 0
    var firstNumberPressed = false
    var secondNumberPressed = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
       resetValues()
    }

    
              //Operation Buttons
    
//Addition button
    @IBAction func addButton(_ sender: Any) {
       detectOperation(operation: "+")
    }
    
//    Subtraction Button
    @IBAction func subtractButton(_ sender: Any) {
        detectOperation(operation: "-")
    }
    
//    Multiplication Button
    @IBAction func multiplyButton(_ sender: Any) {
        detectOperation(operation: "x")
    }
//    Division Button
    @IBAction func divisionButton(_ sender: Any) {
        detectOperation(operation: "/")
    }
    
               //Number Buttons
    
    @IBAction func zeroButton(_ sender: Any) {detectNumber(number: "0")}
    
    @IBAction func numberOneButton(_ sender: Any) { detectNumber(number: "1") }
    
    @IBAction func numberTwoButton(_ sender: Any) { detectNumber(number: "2") }
    
    @IBAction func numberThreeButton(_ sender: Any) { detectNumber(number: "3") }
    
    @IBAction func numberFourButton(_ sender: Any) { detectNumber(number: "4") }
    
    @IBAction func numberFiveButton(_ sender: Any) { detectNumber(number: "5") }
    
    @IBAction func numberSixButton(_ sender: Any) { detectNumber(number: "6") }
    
    @IBAction func numberSevenButton(_ sender: Any) { detectNumber(number: "7") }
    
    @IBAction func numberEightButton(_ sender: Any) {
        detectNumber(number: "8") }
    
    @IBAction func numberNineButton(_ sender: Any) { detectNumber(number: "9") }
    

   
    
    @IBAction func equalButton(_ sender: Any) {
       operationIsUpdated = true
        
        convertToDouble(firstNumber: firstDigit, secondNumber: secondDigit)
        
        
    }
    @IBAction func decimalButton(_ sender: Any) {
        detectNumber(number: ".")
     
    }
   
    
    
    @IBAction func revertButton(_ sender: Any) {
        
    }
    
 
   
    
    @IBAction func percentageButton(_ sender: Any) {
       auxiliaryOperatorIsPressed = true
       operationIsUpdated = true
        updateValue(value: "%")
    }
    
    @IBAction func numberTypeButton(_ sender: Any) {
        auxiliaryOperatorIsPressed = true
        auxiliaryButtonPressCount += 1
         updateValue(value: "+/-")
    }
    
    @IBAction func clearNumberButton(_ sender: Any) {
        operationIsUpdated = false
        resetValues()
        auxiliaryOperatorIsPressed = true
    }
    

    func resetValues() {
        
        firstNumberLbl.text = ""
        operationSymbol.text = ""
        secondNumberLbl.text = ""
        answerLabel.text = "0"
        
    }
    
    //    Detects if a number was selected by the user
        func detectNumber(number: String){
            
            operationIsUpdated = false
            auxiliaryOperatorIsPressed = false
            updateValue(value: number)
           
            
        }
    


    //    Detects if a number was selected by the user
        func detectOperation(operation: String){
            
           
            operationIsUpdated = true
            auxiliaryOperatorIsPressed = false
            updateValue(value: operation)
            
        }
   
  
    func updateValue(value: String) {
      
       
        
        
//        Checks to see if first number is being entered by verifying that the digits before it is empty
        if operationSymbol.text == "" && secondNumberLbl.text == "" && operationIsUpdated != true{
            
            firstNumberPressed = true
            
            guard auxiliaryOperatorIsPressed else{
               
               
                firstNumberLbl.text?.append(value)
                firstDigit = firstNumberLbl.text!
                return
            }
          convertNumberType(digitPressed: &firstNumberLbl.text!)
            
            
            
            
            
        }
       
       
        //        Checks to see if an operation is being entered by verifying that the first digit was entered, the second number was not selected and that a button with an operation value was selected
        
        else if firstNumberLbl.text != "" && secondNumberLbl.text == "" && operationIsUpdated == true {


            switch value {
            
            case "+","-","x","/":
                operationSymbol.text = value
                operationVal = value
                
            case "%":
                
                guard let decimal = Double(firstNumberLbl.text!) else{ return }
 
                    decimalValue = decimal/100
                    firstDigit = "\(decimalValue)"
                    print(decimalValue)
                    firstNumberLbl.text?.append(value)
                
 
                
            default: break
            }
   
        }
 
        else if firstNumberLbl.text != "" && operationSymbol.text != "" && operationIsUpdated != true {
            
            
            secondNumberPressed = true
            
            guard auxiliaryOperatorIsPressed else{
            secondNumberLbl.text?.append(value)
            secondDigit = secondNumberLbl.text!
            return
            }
            convertNumberType(digitPressed: &secondNumberLbl.text!)
        }
        
       
    }
    
    


        
//    Converts selected numbers into int values
    
    func convertToDouble(firstNumber: String, secondNumber: String){
        
        
     
        
        if let firstNum = Double(firstNumber), let secondNum = Double(secondNumber), let op = Operation(rawValue: operationVal) {
           
            
            let equation = Equation(firstNumber: firstNum, secondNumber: secondNum, operationValue: op)
            
            let result = equation.calculate()
        
           
            if let resultedValue = result {
                answerLabel.text = "\(resultedValue)"
            }
            
        }
        
        
    }
    

    func convertNumberType(digitPressed: inout String)  -> String{
        
if auxiliaryButtonPressCount == 1 {
         
                digitPressed.append("-")
     
    }
        
        
        else {

        auxiliaryButtonPressCount = 0
        }

        return digitPressed
    }

    

    
}

